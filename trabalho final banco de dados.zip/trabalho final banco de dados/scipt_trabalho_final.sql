﻿  
--cria o banco de dados STREET LEAGUE SUPER CROWN
--create database street_league_super_crown;

--DELETA TUDO
drop domain if exists attempt cascade;
drop domain if exists place cascade;
drop domain if exists nota cascade;
drop domain if exists somaNota cascade;

drop table if exists tskater cascade;
drop table if exists tsecoes cascade;
drop table if exists resultadoFinal cascade;
drop table if exists flow cascade;
drop table if exists control cascade;
drop table if exists impact cascade;
drop table if exists competicao cascade;
drop table if exists notaMaximaImpact cascade;
drop table if exists eliminado cascade;
drop table if exists skaterCompeticao cascade;
drop view if exists notaMaximaFlow cascade;
drop view if exists notaMaximaControl cascade;

drop type if exists notaNecessaria cascade;

--CRIA OS DIMÍNIOS
create domain attempt as int not null check(value = 2 or value = 5 or value = 6);
create domain place as int not null check(value between 1 and 8);
create domain nota as numeric(3,1) check(value between 0.0 and 10.0);
create domain somaNota as numeric(4,1) check(value <= 60.0 and value >= 0.0);


--tipo de retorno criado  para a função notaNecessaria()
create type notaNecessaria as(
    nome varchar(20),
    sobrenome varchar(20),
    for_leader somaNota,
    place int
);

--tabelas

 create table competicao(
     idCompeticao int,
     nomeCompeticao varchar(80),
     local varchar(80),
     horario time,
     data date,
     temporada int
 );
 
create table tskater(
    id int,
    nome varchar(20) not null,
    sobrenome varchar(20)not null
); 

create table skaterCompeticao(
    idSkater int,
    idCompeticao int
);    

create table eliminado(
    idSkater int,
    idSecao int,
    idCompeticao int
);
    
create table resultadoFinal(
    idSkater int,
    melhorFlow nota,
    melhorControl nota,
    melhorImpact nota,
    totalNota somaNota not null,
    idCompeticao int
);
    
 create table tsecoes(
     id int,
     secao varchar(10),
     totalVoltas attempt
 );           
     
create table flow(
    idSecao int check(idSecao = 1),
    idskater int,
    volta int check(volta <= 2),
    nota nota,
    idCompeticao int
);

create table control(
    idSecao int check(idSecao = 2),
    idskater int,
    volta int check(volta <= 5),
    nota nota,
    idCompeticao int
);

create table impact(
    idSecao int check(idSecao = 3),
    idskater int,
    volta int check(volta <= 6),
    nota nota,
    idCompeticao int
);    

--cria tabela axiliar da bateria impact.para cada atleta retorna as 4 maiores notas
create table notaMaximaImpact(
    idskater int,
    nota nota,
    idCompeticao int
);

--chaves
alter table competicao add primary key(idCompeticao);
alter table competicao add unique(temporada);

alter table tskater add primary key(id);

alter table skaterCompeticao add foreign key(idSkater) references tskater(id);
alter table skaterCompeticao add foreign key(idCompeticao) references competicao(idCompeticao);
alter table skaterCompeticao add primary key(idSkater,idCompeticao);

alter table resultadoFinal add foreign key(idSkater,idCompeticao) references skaterCompeticao(idSkater,idCompeticao);
alter table resultadoFinal add primary key(idSkater,idCompeticao);

alter table tsecoes add unique(totalVoltas,secao);
alter table tsecoes add primary key(id);

alter table eliminado add foreign key(idSkater,idCompeticao) references skaterCompeticao(idSkater,idCompeticao);
alter table eliminado add foreign key(idSecao) references tsecoes(id);
alter table eliminado add primary key(idSkater,idSecao,idCompeticao);

alter table flow add foreign key(idskater,idCompeticao) references skaterCompeticao(idSkater,idCompeticao);
alter table flow add foreign key(idSecao) references tsecoes(id);
alter table flow add primary key(idskater,volta,idSecao,idCompeticao);

alter table control add foreign key(idSkater,idCompeticao) references skaterCompeticao(idSkater,idCompeticao);
alter table control add foreign key(idSecao) references tsecoes(id);
alter table control add primary key(idskater,volta,idSecao,idCompeticao);

alter table impact add foreign key(idSkater,idCompeticao) references skaterCompeticao(idSkater,idCompeticao);
alter table impact add foreign key(idSecao) references tsecoes(id);
alter table impact add primary key(idskater,volta,idSecao,idCompeticao);

alter table notaMaximaImpact add foreign key(idSkater,idCompeticao) references skaterCompeticao(idSkater,idCompeticao);

--views
--cria view da bateria flow.pra cada atleta ele retorna a maior nota
create view notaMaximaFlow as (
select idskater,max(nota) as maiorNotaFlow
from flow
where idCompeticao = 1
group by idskater
order by idskater);

--cria view da bateria control.para cada atleta ele retorna a maior nota
create view notaMaximaControl as (
select idskater,max(nota) as maiorNotaControl
from control 
where idCompeticao = 1
group by idskater
order by idskater);

--funções de gatilhoes
--função que elimina o pior colocado do flow
create or replace function eliminarFlow() returns trigger as $$
    declare
        piorColocadoFlow int;
        totalflow int;
        menorFlow nota;
    begin
    
        select count(nota)
        into totalFlow 
        from flow 
        where idCompeticao = new.idCompeticao 
        group by idCompeticao;--conta se a bateria foi completada
        
        if totalFlow = 16 then--se a bateria flow foi completa
            select idskater,min(maiorNotaFlow) 
            into piorColocadoFlow,menorFlow 
            from notaMaximaFlow 
            group by idskater;--pega a menor nota da view flow e insere em menorFlow
            
            insert into eliminado(idSkater,idSecao,idCompeticao) 
            values(piorColocadoFlow,1,new.idCompeticao);
        end if;
    
        return new;      
    end;
$$ language plpgsql;
 
--função que elimina o pior colocado do control
create or replace function eliminarControl() returns trigger as $$
    declare
        piorColocadoControl int;
        totalControl int;
        menorControl nota;

    begin
    
        select count(nota) 
        into totalControl 
        from control
        where idCompeticao = new.idCompeticao
        group by idCompeticao;--conta se a bateria foi completada
        
        if totalControl = 35 then--se a bateria control foi completa
            select idskater,min(maiorNotaControl) 
            into piorColocadoControl,menorControl 
            from notaMaximaControl 
            group by idskater;--pega a menor nota da view control e insere em menorcontrol
            
            insert into eliminado(idSkater,idSecao,idCompeticao) 
            values(piorColocadoControl,2,new.idCompeticao);
        end if;
        
        return new;      
    end;
$$ language plpgsql;
 
--função que verifica se o atleta foi eliminado
create or replace function verificar_eliminado() returns trigger as $$
    declare
         idSkater2 int;
    begin
        select idSkater into idSkater2 
        from eliminado 
        where idSkater = new.idskater and idCompeticao = new.idCompeticao;
        
        if new.idskater = idSkater2 and new.nota is not null then
            raise exception 'atleta eliminado!!Selecione outro atleta.';
        end if;  
        return new;  
    end;
$$ language plpgsql;
 
--função de gatilho que retorna as quatro maiores notas de impact
create or replace function maiores_impact() returns trigger as $$
    declare 
        soma somaNota;
        notaImpact nota;
        id int;
    begin
        if new.volta <= 4 and new.nota is not null then
            insert into notaMaximaImpact(idskater,nota,idCompeticao) 
            values(new.idskater,new.nota,new.idCompeticao);
        end if;
   
        if new.volta > 4 and new.nota is not null then
        
            select idskater,min(nota) into id,notaImpact 
            from notaMaximaImpact 
            where idskater = new.idskater and idCompeticao = new.idCompeticao 
            group by idskater;

            --se a nova nota é maior que a menor das 4 então...
            if new.nota > notaImpact then
                --atualiza a tabela notamaximaimpact onde a nota é a menor 
                update notaMaximaImpact 
                set nota = new.nota
                where nota = notaImpact;
            end if;
            
        end if;
        return new;
    end;
 $$ language plpgsql;

--função que povoa a tabela resultado final com as maiores notas de flow
create or replace function resultadoFinalFlow() returns trigger as $$
    declare
        maxFlow nota;
    begin
       
        if new.idSecao = 1 then
        
            select maiorNotaFlow 
            into maxFlow 
            from notaMaximaFlow 
            where idskater = new.idskater;
            
            update resultadoFinal 
            set melhorFlow = maxFlow,totalNota = maxFlow 
            where idSkater = new.idskater and idCompeticao = new.idCompeticao;            
  
        end if; 
        return new;   
    end;
$$ language plpgsql;   

--função que povoa a tabela resultado final com as maiores notas de control
create or replace function resultadoFinalControl() returns trigger as $$
    declare
        maxControl nota;
        maxFlow nota;
        soma somaNota;
    begin
        if new.idSecao = 2 then

            select melhorFlow
            into maxFlow
            from resultadoFinal
            where idSkater = new.idskater and idCompeticao = new.idCompeticao;
        
            select maiorNotaControl 
            into maxControl 
            from notaMaximaControl 
            where idskater = new.idskater;

            soma = maxFlow + maxControl;
            
            update resultadoFinal 
            set melhorControl = maxControl,totalNota = Soma
            where idSkater = new.idskater and idCompeticao = new.idCompeticao;
            
        end if; 
        return new;   
    end;
$$ language plpgsql;   

--função que povoa resultado final com a maior nota impact
create or replace function resultadoFinalImpact() returns trigger as $$
    declare
        maxImpact nota;
        maxFlow nota;
        maxControl nota;
        somaImpact somaNota;
        soma somaNota;
    begin
        if new.idSecao = 3 then
        
            select max(nota),sum(nota) 
            into maxImpact,somaImpact
            from notaMaximaImpact 
            where idskater = new.idskater and idCompeticao = new.idCompeticao 
            group by idskater; 
            
            select melhorFlow,melhorControl
            into maxFlow,maxControl
            from resultadoFinal
            where idSkater = new.idskater and idCompeticao = new.idCompeticao;

            soma = somaImpact + maxFlow + maxControl;
            
            update resultadoFinal 
            set melhorImpact = maxImpact,totalNota = soma 
            where idSkater = new.idskater and idCompeticao = new.idCompeticao;
            
        end if;
        return new;    
    end;
$$ language plpgsql;

--funções normais
--função inserir notas flow
 create or replace function inserir_nota_flow(idsec int,
                                             idska int,
                                             vol int,
                                             nota nota,
                                             compet int) returns void as $$
     begin
         insert into flow values(idsec,idska,vol,nota,compet);
     end;
  $$ language plpgsql;

--função inserir nota impact
create or replace function inserir_nota_impact(idsec int,
                                             idska int,
                                             vol int,
                                             nota nota,
                                             compet int) returns void as $$
    begin
        insert into impact values(idsec,idska,vol,nota,compet);
    end;
$$ language plpgsql;
        
--função inserir nota control
create or replace function inserir_nota_control(idsec int,
                                             idska int,
                                             vol int,
                                             nota nota,
                                             compet int) returns void as $$
    begin
        insert into control values(idsec,idska,vol,nota,compet);
    end;
 $$ language plpgsql;

--função que mostra a nota necessaria pra ir pra 1° colocação.    
create or replace function notaNecessaria(skater int
                                         ,competicao int) returns notaNecessaria as $$
    declare
        dados notaNecessaria;
        nomeAtleta varchar(20);
        notaTotalAtleta somaNota;
        notaTotalLider somaNota;
    begin
        select nome,sobrenome
        into dados.nome,dados.sobrenome
        from tskater inner join skaterCompeticao
        on id = skater and idCompeticao = competicao and idSkater = skater;
        
        select totalNota
        into notaTotalAtleta
        from resultadoFinal
        where idSkater = skater and idCompeticao = competicao;
        
        select max(totalNota)
        into notaTotalLider
        from resultadoFinal 
        group by idCompeticao;
        dados.place = 2;
        dados.for_leader = notaTotalLider - notaTotalAtleta;
        
        return dados;
    end;
$$ language plpgsql;

--gatilhos
--gatilho para eliminar o pior colocado do flow
create trigger eliminarFlow after insert or update
on flow for each row execute procedure eliminarFlow();

--gatilho para eliminar o pior colocado do flow
create trigger eliminarControl after insert or update
on control for each row execute procedure eliminarControl();

--criar gatilho verificar eliminado para control
create trigger verificar_eliminado before insert or update
on control for each row execute procedure verificar_eliminado();

--criar gatilho verificar eliminado para impact
create trigger verificar_eliminado before insert or update
on impact for each row execute procedure verificar_eliminado();

--cria gatilho moiores_impact na tabela impact
create trigger maiores_impact before insert or update
on impact for each row execute procedure maiores_impact();

 --criar gatilho resultado final flow
 create trigger resultadoFinalFlow after insert or update
on flow for each row execute procedure resultadoFinalFlow();

 --criar gatilho resultado final control
 create trigger resultadoFinalControl after insert or update
on control for each row execute procedure resultadoFinalControl();

 --criar gatilho resultado final impact
create trigger resultadoFinalImpact after insert or update
on impact for each row execute procedure resultadoFinalImpact();

--inserções
insert into competicao(idCompeticao,nomeCompeticao,local,horario,data,temporada) values
(1,'STREET LEAGUE SUPER CROWN','LOS ANGELES-CALIFORNIA','13:00:00','28/12/2017',2017);

insert into tsecoes(id,secao,totalVoltas) values
     (1,'FLOW',2),
     (2,'CONTROL',5),
     (3,'IMPACT',6);
     
insert into tskater(id,nome,sobrenome) values
     (1,'LUAN','OLIVEIRA'),
     (2,'NYJAH','HUSTON'),
     (3,'PAUL','RODRIGUES'),
     (4,'TOREY','PUDWILL'),
     (5,'CRIS','COLE'),
     (6,'SHANE','O´NEIL'),
     (7,'SHEAN','MATO'),
     (8,'KELVIN','HOEFLER');

insert into skaterCompeticao(idSkater,idCompeticao) values
    (1,1),(2,1),(3,1),(4,1),(5,1),(6,1),(7,1),(8,1);
    
insert into resultadoFinal(idSkater,totalNota,idCompeticao) values
(1,0.0,1),(2,0.0,1),(3,0.0,1),(4,0.0,1),(5,0.0,1),(6,0.0,1),(7,0.0,1),(8,0.0,1);

 insert into flow(idSecao,idskater,volta,nota,idCompeticao) values
     (1,1,1,3.5,1),
     (1,2,1,6.5,1),
     (1,3,1,7.5,1),
     (1,4,1,8.5,1),
     (1,5,1,8.5,1),
     (1,6,1,7.5,1),
     (1,7,1,9.5,1),
     (1,8,1,8.5,1),
     (1,1,2,6.5,1),
     (1,2,2,9.5,1),
     (1,3,2,5.5,1),
     (1,4,2,7.5,1),
     (1,5,2,8.5,1),
     (1,6,2,7.5,1),
     (1,7,2,8.5,1);


--informe o id do atleta e o número da competição     
select notaNecessaria(1,1) as nota_necessaria_para_ser_lider;
 
--forneça o id da seção,id do skatista,a volta,a nota,o número da competição.   
select inserir_nota_flow(1,8,2,10.0,1);

insert into control(idSecao,idskater,volta,nota,idCompeticao) values
     (2,2,1,8.6,1),
     (2,3,1,6.5,1),
     (2,4,1,8.9,1),
     (2,5,1,9.0,1),
     (2,6,1,7.0,1),
     (2,7,1,8.3,1),
     (2,8,1,7.6,1),
     (2,2,2,0.0,1),
     (2,3,2,5.6,1),
     (2,4,2,7.8,1),
     (2,5,2,6.9,1),
     (2,6,2,4.5,1),
     (2,7,2,9.6,1),
     (2,8,2,8.2,1),
     (2,2,3,7.0,1),
     (2,3,3,9.1,1),
     (2,4,3,9.0,1),
     (2,5,3,5.9,1),
     (2,6,3,8.1,1),
     (2,7,3,8.4,1),
     (2,8,3,7.3,1),
     (2,2,4,8.4,1),
     (2,3,4,0.0,1),
     (2,4,4,0.0,1),
     (2,5,4,0.0,1),
     (2,6,4,7.8,1),
     (2,7,4,0.0,1),
     (2,8,4,6.5,1),
     (2,2,5,7.4,1),
     (2,3,5,2.3,1),
     (2,4,5,0.0,1),
     (2,5,5,7.3,1),
     (2,6,5,5.6,1),
     (2,7,5,8.0,1);
     
--forneça o id da seção,id do skatista,a volta,a nota,o número da competição.   
select inserir_nota_control(2,8,5,10.0,1);

 insert into impact(idsecao,idskater,volta,nota,idCompeticao) values
     (3,3,1,0.0,1),
     (3,3,2,5.6,1),
     (3,3,3,7.8,1),
     (3,3,4,8.9,1),
     (3,3,5,10.0,1),
     (3,3,6,10.0,1),
     (3,4,1,0.0,1),
     (3,4,2,6.5,1),
     (3,4,3,7.8,1),
     (3,4,4,0.0,1),
     (3,4,5,0.0,1),
     (3,4,6,7.8,1),
     (3,5,1,7.9,1),
     (3,5,2,8.1,1),
     (3,5,3,0.0,1),
     (3,5,4,6.8,1),
     (3,5,5,9.0,1),
     (3,5,6,8.2,1),
     (3,6,1,7.8,1),
     (3,6,2,0.0,1),
     (3,6,3,8.9,1),
     (3,6,4,8.5,1),
     (3,6,5,4.5,1),
     (3,6,6,7.6,1),
     (3,7,1,6.8,1),
     (3,7,2,9.8,1),
     (3,7,3,6.7,1),
     (3,7,4,4.5,1),
     (3,7,5,0.0,1),
     (3,7,6,9.2,1),
     (3,8,1,8.4,1),
     (3,8,2,8.6,1),
     (3,8,3,0.0,1),
     (3,8,4,7.3,1),
     (3,8,5,9.1,1);
     
--forneça o id da seção,id do skatista,a volta,a nota,o número da competição.   
select inserir_nota_impact(3,8,6,7.8,1);
     
--select * from flow;
--select * from control;
--select * from impact;
--select * from tskater;
--select * from skaterCompeticao;
--select * from eliminado;
--select * from resultadoFinal order by totalNota desc;
--select * from notaMaximaFlow;
--select * from notaMaximaControl;
--select * from notaMaximaImpact; 
--select * from competicao;  

--retorna as colocações finais de cada atleta
select nome,sobrenome,totalNota
from tskater inner join resultadoFinal
on tskater.id = resultadoFinal.idSkater
order by totalNota desc;

--select nome 
--from
--(select t.nome,t.id,s.idCompeticao
--from tskater as t inner join skaterCompeticao as s
--on t.id = s.idSkater) as f inner join resultadoFinal as r
--on f.idCompeticao = r.idCompeticao and r.totalNota = 10.0 and f.id = r.idSkater;
   